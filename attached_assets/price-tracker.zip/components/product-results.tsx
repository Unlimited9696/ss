"use client"

import { useSearchParams } from "next/navigation"
import { useEffect, useState } from "react"
import Image from "next/image"
import { ExternalLink, ArrowDown, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Mock data - in a real app this would come from API calls to your backend
// which would then fetch data from Amazon and Flipkart
const mockProducts = [
  {
    id: 1,
    name: "Apple iPhone 15 (128GB) - Blue",
    image: "/placeholder.svg?height=200&width=200",
    prices: {
      amazon: 74900,
      flipkart: 73499,
    },
    ratings: {
      amazon: 4.5,
      flipkart: 4.6,
    },
    inStock: {
      amazon: true,
      flipkart: true,
    },
    links: {
      amazon: "https://www.amazon.in/",
      flipkart: "https://www.flipkart.com/",
    },
  },
  {
    id: 2,
    name: "Samsung Galaxy S23 Ultra (256GB) - Phantom Black",
    image: "/placeholder.svg?height=200&width=200",
    prices: {
      amazon: 99999,
      flipkart: 97999,
    },
    ratings: {
      amazon: 4.7,
      flipkart: 4.5,
    },
    inStock: {
      amazon: true,
      flipkart: true,
    },
    links: {
      amazon: "https://www.amazon.in/",
      flipkart: "https://www.flipkart.com/",
    },
  },
  {
    id: 3,
    name: "Sony WH-1000XM5 Wireless Noise Cancelling Headphones",
    image: "/placeholder.svg?height=200&width=200",
    prices: {
      amazon: 29990,
      flipkart: 31990,
    },
    ratings: {
      amazon: 4.8,
      flipkart: 4.7,
    },
    inStock: {
      amazon: true,
      flipkart: false,
    },
    links: {
      amazon: "https://www.amazon.in/",
      flipkart: "https://www.flipkart.com/",
    },
  },
]

export function ProductResults() {
  const searchParams = useSearchParams()
  const query = searchParams.get("q")
  const [loading, setLoading] = useState(false)
  const [products, setProducts] = useState<typeof mockProducts>([])

  useEffect(() => {
    if (query) {
      setLoading(true)

      // Simulate API call delay
      const timer = setTimeout(() => {
        // In a real app, you would fetch data from your backend API
        // which would then fetch from Amazon and Flipkart
        setProducts(mockProducts)
        setLoading(false)
      }, 1500)

      return () => clearTimeout(timer)
    } else {
      setProducts([])
    }
  }, [query])

  if (!query) {
    return (
      <div className="text-center text-slate-500 dark:text-slate-400">
        <p>Search for a product to see price comparisons</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="mt-4 text-slate-600 dark:text-slate-300">
          Searching for &quot;{query}&quot; across multiple stores...
        </p>
      </div>
    )
  }

  if (products.length === 0 && !loading && query) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-600 dark:text-slate-300">
          No products found for &quot;{query}&quot;. Try a different search term.
        </p>
      </div>
    )
  }

  return (
    <div>
      <h2 className="mb-6 text-2xl font-semibold text-slate-900 dark:text-white">Results for &quot;{query}&quot;</h2>
      <p className="mb-4 text-sm text-slate-500 dark:text-slate-400">
        Note: This is a demo with mock data. In a real implementation, links would go to actual product pages.
      </p>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {products.map((product) => {
          const amazonPrice = product.prices.amazon
          const flipkartPrice = product.prices.flipkart
          const priceDiff = amazonPrice - flipkartPrice
          const cheaperOn = priceDiff > 0 ? "flipkart" : priceDiff < 0 ? "amazon" : null
          const savingsAmount = Math.abs(priceDiff)
          const savingsPercent = ((savingsAmount / Math.max(amazonPrice, flipkartPrice)) * 100).toFixed(1)

          return (
            <Card key={product.id} className="overflow-hidden">
              <div className="p-4 flex justify-center bg-slate-50 dark:bg-slate-800">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  width={150}
                  height={150}
                  className="object-contain h-[150px]"
                />
              </div>

              <CardContent className="p-4">
                <h3 className="font-medium text-slate-900 dark:text-white line-clamp-2 h-12">{product.name}</h3>

                {cheaperOn && (
                  <Badge
                    variant="outline"
                    className="mt-2 bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400 border-green-200 dark:border-green-800"
                  >
                    Save ₹{savingsAmount.toLocaleString()} ({savingsPercent}%) on{" "}
                    {cheaperOn.charAt(0).toUpperCase() + cheaperOn.slice(1)}
                  </Badge>
                )}

                <Tabs defaultValue="comparison" className="mt-4">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="comparison">Comparison</TabsTrigger>
                    <TabsTrigger value="details">Details</TabsTrigger>
                  </TabsList>

                  <TabsContent value="comparison" className="mt-4">
                    <div className="grid grid-cols-2 gap-2">
                      <div
                        className={`p-3 rounded-lg border ${cheaperOn === "amazon" ? "bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800" : "bg-slate-50 border-slate-200 dark:bg-slate-800 dark:border-slate-700"}`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">Amazon</span>
                          <span className="text-xs">{product.ratings.amazon} ★</span>
                        </div>
                        <div className="mt-1 text-lg font-bold">₹{product.prices.amazon.toLocaleString()}</div>
                        {cheaperOn === "amazon" && (
                          <div className="mt-1 flex items-center text-xs text-green-600 dark:text-green-400">
                            <ArrowDown className="h-3 w-3 mr-1" />
                            Lowest price
                          </div>
                        )}
                      </div>

                      <div
                        className={`p-3 rounded-lg border ${cheaperOn === "flipkart" ? "bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800" : "bg-slate-50 border-slate-200 dark:bg-slate-800 dark:border-slate-700"}`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">Flipkart</span>
                          <span className="text-xs">{product.ratings.flipkart} ★</span>
                        </div>
                        <div className="mt-1 text-lg font-bold">₹{product.prices.flipkart.toLocaleString()}</div>
                        {cheaperOn === "flipkart" && (
                          <div className="mt-1 flex items-center text-xs text-green-600 dark:text-green-400">
                            <ArrowDown className="h-3 w-3 mr-1" />
                            Lowest price
                          </div>
                        )}
                        {!product.inStock.flipkart && (
                          <div className="mt-1 text-xs text-red-600 dark:text-red-400">Out of stock</div>
                        )}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="details">
                    <div className="space-y-3">
                      <div>
                        <h4 className="text-sm font-medium">Availability</h4>
                        <div className="mt-1 grid grid-cols-2 gap-2 text-sm">
                          <div>Amazon: {product.inStock.amazon ? "In Stock" : "Out of Stock"}</div>
                          <div>Flipkart: {product.inStock.flipkart ? "In Stock" : "Out of Stock"}</div>
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-medium">Price History</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                          Price tracking data would appear here in a real app
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>

                <div className="mt-4 grid grid-cols-2 gap-2">
                  <Button asChild variant="outline" size="sm">
                    <a
                      href={product.links.amazon}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center"
                    >
                      Visit Amazon
                      <ExternalLink className="ml-1 h-3 w-3" />
                    </a>
                  </Button>
                  <Button asChild variant="outline" size="sm" disabled={!product.inStock.flipkart}>
                    <a
                      href={product.links.flipkart}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center"
                    >
                      Visit Flipkart
                      <ExternalLink className="ml-1 h-3 w-3" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}

