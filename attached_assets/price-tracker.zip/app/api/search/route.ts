import { type NextRequest, NextResponse } from "next/server"
import { fetchProductPrices } from "@/lib/price-fetcher"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const query = searchParams.get("q")

  if (!query) {
    return NextResponse.json({ error: "Search query is required" }, { status: 400 })
  }

  try {
    // In a real app, this would call your actual price fetching service
    // which would handle scraping or API calls to e-commerce sites
    const products = await fetchProductPrices(query)

    return NextResponse.json({ products })
  } catch (error) {
    console.error("Error fetching product prices:", error)
    return NextResponse.json({ error: "Failed to fetch product prices" }, { status: 500 })
  }
}

