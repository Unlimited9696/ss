"use client"

import { useEffect, useRef } from "react"

interface PricePoint {
  date: string
  amazon: number
  flipkart: number
}

interface PriceHistoryChartProps {
  data: PricePoint[]
  height?: number
}

// This is a placeholder component for a price history chart
// In a real app, you would use a charting library like Chart.js, Recharts, or D3.js
export function PriceHistoryChart({ data, height = 200 }: PriceHistoryChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current || data.length === 0) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // In a real app, you would render a proper chart here
    // This is just a placeholder visualization
    ctx.font = "14px Arial"
    ctx.fillStyle = "#666"
    ctx.fillText("Price history chart would appear here", 20, height / 2)
    ctx.fillText("(Using a proper charting library)", 20, height / 2 + 20)

    // Draw a simple line to indicate this is a chart
    ctx.beginPath()
    ctx.moveTo(20, height - 40)
    ctx.lineTo(canvas.width - 20, height - 40)
    ctx.strokeStyle = "#ddd"
    ctx.stroke()
  }, [data, height])

  return <canvas ref={canvasRef} width="100%" height={height} className="w-full" />
}

